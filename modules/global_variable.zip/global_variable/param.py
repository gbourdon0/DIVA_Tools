from modules.global_variable.default_param import default_plot_param

plot_param = default_plot_param

#Plot param
default_plot_param ={
    "cmap":"jet",#jet_r
    "linewidths":1,
    "linestyles":"-",
    "zorder":10,
    "line_color":"k"
}